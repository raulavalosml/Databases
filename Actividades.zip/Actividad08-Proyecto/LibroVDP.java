import java.util.*;

public class LibroVDP
{
	private String clave, titulo, date, time;
    private int    stock,cantidad, nueva;
    private float  total;
	
	
	// Constructores
	public LibroVDP()
	{
        this.clave     = "";
		this.titulo    = "";
		this.stock     = 0;
		this.cantidad  = 0;
        this.nueva = 0;
        this.total    = 0;
        this.date ="";
        this.time ="";
	}
	
	public LibroVDP(String datos)
	{
		StringTokenizer st = new StringTokenizer(datos,"_");
		
        this.clave     = st.nextToken();
		this.titulo    = st.nextToken();
		this.stock     = Integer.parseInt(st.nextToken()); //cambiar a int
		this.cantidad = Integer.parseInt(st.nextToken());
        this.nueva = Integer.parseInt(st.nextToken());
        this.total    = Float.parseFloat(st.nextToken());
        this.date = st.nextToken();
        this.time = st.nextToken();
	}
	
	// Accesors (geter)
    public String getClave()
    {
        return this.clave;
    }
  
    public String getTitulo()
	{
		return this.titulo;
	}
	
	public int getStock()
	{
		return this.stock;
	}
	
	public int getCantidad()
	{
		return this.cantidad;
	}
    
    public int getNueva()
    {
        return this.nueva;
    }
    
    public float getTotal()
    {
        return this.total;
    }
    
    public String getDate()
    {
        return this.date;
    }
    
    public String getTime()
    {
        return this.time;
    }
	
	// Mutators (seter)
    public void setClave(String cve)
    {
        this.clave = cve;
    }
    
    public void setTitulo(String tit)
	{
		this.titulo = tit;
	}
	
	public void setStock(int stc)
	{
		this.stock = stc;
	}
	
	public void setCantidad(int canti)
	{
		this.cantidad = canti;
	}
    
    public void setNueva(int nue)
    {
        this.nueva = nue;
    }
    
    public void setTotal(float tot)
    {
        this.total = tot;
    }
    
    public void setDate(String dt)
    {
    	this.date = dt;
    }
	
	public void setTime(String t)
	{
		this.time = t;
	}
	
	public String toStringVenta()
	{
		return this.clave+"_"+this.titulo+"_"+this.stock+"_"+this.cantidad+"_"+this.nueva+"_"+this.total+"_"+this.date+"_"+this.time;
	}
	
	public String toStringSqlVenta()
	{
		return "'"+this.clave+"','"+this.titulo+"',"+this.stock+","+this.cantidad+","+this.nueva+","+this.total+",'"+this.date+"','"+this.time+"'";
	}
}
