import java.io.PrintWriter;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;

public class BiblioAD
{
    private PrintWriter archivoOut;
    private BufferedReader archivoIn;
    
    public String capturar(String datos)
    {
        String respuesta;
        
        try
        {
            // 1. Abrir el archivo de datos
            archivoOut = new PrintWriter(new FileWriter("Libros.txt",true));
        
            // 2. Capturar los datos en el archivo
            archivoOut.println(datos);
            
            // 3. Cerrar archivo
            archivoOut.close();
            
            respuesta = "Captura correcta... ";
        }
        catch(IOException ioe)
        {
            respuesta = "Error en captura: "+ioe;
            System.out.println("Error: "+ioe);
        }
        
        return respuesta;
    }
    
    public String consultarLibros()
    {
        String datos="";
        
        try
        {
            // 1. Abrir el archivo para leer los datos
            archivoIn = new BufferedReader(new FileReader("Libros.txt"));
        
            // 2. Procesar los datos
            while(archivoIn.ready())
            {
                datos = datos + archivoIn.readLine() + "\n";
            }
            
            // 3. Cerrar el archivo
            archivoIn.close();
        }
        catch(FileNotFoundException fnfe)
        {
            datos = "Error en consultar libros: "+fnfe;
            System.out.println("Error: "+fnfe);
        }
        catch(IOException ioe)
        {
            datos = "Error en consultar: "+ioe;
            System.out.println("Error: "+ioe);
        }
        
        return datos;
    }
}







