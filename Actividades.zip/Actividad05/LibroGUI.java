import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LibroGUI extends JFrame implements ActionListener
{
    private JTextField tfClave,tfTitulo, tfAutor, tfEditorial,tfCantidad,tfPrecio;
    private JButton    bCapturar, bConsultar, bSalir,bConsultarEdit;
    private JTextArea  taDatos;
    private JPanel panel1, panel2;
    
    //private BiblioAD biblioad = new BiblioAD();
    private BiblioADjdbc biblioad = new BiblioADjdbc();
    
    public LibroGUI()
    {
        super("Biblioteca Tec");
        
        // 1. Crear objetos de los atributos
        tfClave     = new JTextField();
        tfCantidad  = new JTextField();
        tfPrecio    = new JTextField();
        tfTitulo    = new JTextField();
        tfAutor     = new JTextField();
        tfEditorial = new JTextField();
        bCapturar   = new JButton("Capturar datos");
        bConsultar  = new JButton("Consultar Libros");
        bConsultarEdit = new JButton("Consultar por Edit");
        bSalir      = new JButton("Exit");
        taDatos     = new JTextArea(10,30);
        panel1      = new JPanel();
        panel2      = new JPanel();
        
        // 1.2 Adicionar addActionListener a los JButtons
        bCapturar.addActionListener(this);
        bConsultar.addActionListener(this);
        bConsultarEdit.addActionListener(this);
        bSalir.addActionListener(this);
        
        // 2. Definir el Layout de los JPanels
        panel1.setLayout(new GridLayout(11,2));
        panel2.setLayout(new FlowLayout());
        
        // 3. Colocar los objetos en los JPanels
        panel1.add(new JLabel("CLAVE: "));
        panel1.add(tfClave);
        panel1.add(new JLabel("TITULO: "));
        panel1.add(tfTitulo);
        panel1.add(new JLabel("AUTOR: "));
        panel1.add(tfAutor);
        panel1.add(new JLabel("EDITORIAL: "));
        panel1.add(tfEditorial);
        panel1.add(new JLabel("CANTIDAD: "));
        panel1.add(tfCantidad);
        panel1.add(new JLabel("PRECIO: "));
        panel1.add(tfPrecio);
        panel1.add(bCapturar);
        panel1.add(bConsultar);
        panel1.add(bConsultarEdit);
        panel1.add(bSalir);
        
        panel2.add(panel1);
        panel2.add(new JScrollPane(taDatos));
        
        // 4. Adicionar los JPanels al JFrame
        add(panel2);
        
        // 5. Visualizar el JFrame
        setSize(400,600);
        setVisible(true);
    }
    
    private String obtenerDatos()
    {
    	String clave  = tfClave.getText();
        String titulo = tfTitulo.getText();
        String autor  = tfAutor.getText();
        String edit   = tfEditorial.getText();
        String cantidad = tfCantidad.getText();
        String precio = tfPrecio.getText();
        
        /*if((clave==null)||(titulo==null)||(autor==null)||(edit==null)||(cantidad==null)||(precio==null))
        {
        	System.out.println("Algun elemento esta va�o\n");
        	return "VACIO";
        }
        else
        {
        	return clave+""+titulo+"_"+autor+"_"+edit+""+cantidad+""+precio;
        
        }
        /*if(Comunes.isNumeric())
        {
        	
        }
        else
        {
        	System.out.println("No es numero...")
        }*/
        return clave+""+titulo+"_"+autor+"_"+edit+""+cantidad+""+precio;
    }
    
    public void actionPerformed(ActionEvent e)
    {
        String datos, resultado;
        
        if(e.getSource() == bCapturar)
        {
            //taDatos.append("Capturar datos...\n");
            // 1. Obtener datos de los JTextFields
            datos = obtenerDatos();
            
            // 2. Capturar datos en el archivo
            resultado = biblioad.capturar(datos);
            
            // 3. Desplegar resultado de la Transaccion
            //taDatos.setText(resultado);
            taDatos.setText(resultado);
        }
        
        if(e.getSource() == bConsultar)
        {
            //taDatos.append("Consultar libros...\n");
            // 1. Consultar libros
            datos = biblioad.consultarLibros();
            
            // 2. Desplegar datos
            taDatos.setText(datos);
        }
        
        if(e.getSource() == bConsultarEdit)
        {
        	String edit   = tfEditorial.getText();
            //taDatos.append("Consultar libros...\n");
            // 1. Consultar libros
            datos = biblioad.consultarLibrosPor("editorial",edit);
            
            // 2. Desplegar datos
            taDatos.setText(datos);
        }
        
        if(e.getSource() == bSalir)
        {
            System.exit(0);
        }
    }
    
    public static void main(String args[])
    {
        new LibroGUI();
    }
}
