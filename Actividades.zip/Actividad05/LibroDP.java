import java.util.*;

public class LibroDP
{
	private String clave, titulo, autor, editorial, cantidad, precio;
	
	
	// Constructores
	public LibroDP()
	{
		this.clave     = "";
		this.titulo    = "";
		this.autor     = "";
		this.editorial = "";
		this.cantidad  = "";
		this.precio    = "";
	}
	
	public LibroDP(String datos)
	{
		StringTokenizer st = new StringTokenizer(datos,"_");
		
		this.clave     = st.nextToken();
		this.titulo    = st.nextToken();
		this.autor     = st.nextToken();
		this.editorial = st.nextToken();
		this.cantidad  = st.nextToken();
		this.precio    = st.nextToken();
	}
	
	// Accesors (geter)
	public String getClave()
	{
		return this.clave;
	}
	
	public String getTitulo()
	{
		return this.titulo;
	}
	
	public String getAutor()
	{
		return this.autor;
	}
	
	public String getEditorial()
	{
		return this.editorial;
	}
	
	public String getCantidad()
	{
		return this.cantidad;
	}
	
	public String getPrecio()
	{
		return this.precio;
	}
	
	// Mutators (seter)
	public void setClave(String cla)
	{
		this.clave = cla;
	}
	
	public void setTitulo(String tit)
	{
		this.titulo = tit;
	}
	
	public void setAutor(String aut)
	{
		this.autor = aut;
	}
	
	public void setEditorial(String edit)
	{
		this.editorial = edit;
	}
	
	public void setCantidad(String cant)
	{
		this.cantidad = cant;
	}
	
	public void setPrecio(String pre)
	{
		this.precio = pre;
	}
	
	public String toString()
	{
		return this.clave+"_"+this.titulo+"_"+this.autor+"_"+this.editorial+"_"+this.cantidad+"_"+this.precio;
	}
	
	public String toStringSql()
	{
		return "'"+this.clave+"','"+this.titulo+"','"+this.autor+"','"+this.editorial+"','"+this.cantidad+"','"+this.precio+"'";
	}
}