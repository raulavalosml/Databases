import java.util.*;

public class LibroDP
{
	private String clave, titulo, autor, editorial;
    private int    existencia;
    private float  precio;
	
	
	// Constructores
	public LibroDP()
	{
        this.clave     = "";
		this.titulo    = "";
		this.autor     = "";
		this.editorial = "";
        this.existencia = 0;
        this.precio    = 0;
	}
	
	public LibroDP(String datos)
	{
		StringTokenizer st = new StringTokenizer(datos,"_");
		
        this.clave     = st.nextToken();
		this.titulo    = st.nextToken();
		this.autor     = st.nextToken();
		this.editorial = st.nextToken();
        this.existencia = Integer.parseInt(st.nextToken());
        this.precio    = Float.parseFloat(st.nextToken());
	}
	
	// Accesors (geter)
    public String getClave()
    {
        return this.clave;
    }
  
    public String getTitulo()
	{
		return this.titulo;
	}
	
	public String getAutor()
	{
		return this.autor;
	}
	
	public String getEditorial()
	{
		return this.editorial;
	}
    
    public int getExistencia()
    {
        return this.existencia;
    }
    
    public float getPrecio()
    {
        return this.precio;
    }
    
	
	// Mutators (seter)
    public void setClave(String cve)
    {
        this.clave = cve;
    }
    
    public void setTitulo(String tit)
	{
		this.titulo = tit;
	}
	
	public void setAutor(String aut)
	{
		this.autor = aut;
	}
	
	public void setEditorial(String edit)
	{
		this.editorial = edit;
	}
    
    public void setExistencia(int cantidad)
    {
        this.existencia = cantidad;
    }
    
    public void setPrecio(float pre)
    {
        this.precio = pre;
    }
    
	
	public String toString()
	{
		return this.clave+"_"+this.titulo+"_"+this.autor+"_"+this.editorial+"_"+this.existencia+"_"+this.precio;
	}
	
	public String toStringSql()
	{
		return "'"+this.clave+"','"+this.titulo+"','"+this.autor+"','"+this.editorial+"',"+this.existencia+","+this.precio;
	}
}
