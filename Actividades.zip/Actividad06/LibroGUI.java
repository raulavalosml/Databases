import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JOptionPane;

import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LibroGUI extends JFrame implements ActionListener
{
    private JTextField tfClave, tfTitulo, tfAutor, tfEditorial, tfExistencia, tfPrecio;
    private JButton    bCapturar, bConsultar, bConsultarEditorial, bConsultarClave, bSalir, bActualizarStock, bCancelar, bVenta;
    private JTextArea  taDatos;
    private JPanel panel1, panel2;
    
    //private BiblioAD biblioad = new BiblioAD();
    private BiblioADjdbc biblioad = new BiblioADjdbc();
    
    public LibroGUI()
    {
        super("Biblioteca Tec");
        
        // 1. Crear objetos de los atributos
        tfClave     = new JTextField();
        tfTitulo    = new JTextField();
        tfAutor     = new JTextField();
        tfEditorial = new JTextField();
        tfExistencia = new JTextField();
        tfPrecio    = new JTextField();
        bCapturar   = new JButton("Capturar datos");
        bConsultar  = new JButton("Consultar Libros");
        bConsultarEditorial = new JButton("Consultar Editorial");
        bConsultarClave = new JButton("Consultar Clave");
        bActualizarStock = new JButton("Actualizar Stock");
        bVenta = new JButton("Venta de Libros");
        bCancelar   = new JButton("Cancelar"); 
        bSalir      = new JButton("Exit");
        taDatos     = new JTextArea(8,25);
        panel1      = new JPanel();
        panel2      = new JPanel();
        
        // 1.2 Adicionar addActionListener a los JButtons
        bCapturar.addActionListener(this);
        bConsultar.addActionListener(this);
        bConsultarEditorial.addActionListener(this);
        bConsultarClave.addActionListener(this);
        bActualizarStock.addActionListener(this);
        bVenta.addActionListener(this);
        bCancelar.addActionListener(this);
        bSalir.addActionListener(this);
        
        bActualizarStock.setEnabled(false);
        bCancelar.setEnabled(false);
        bVenta.setEnabled(false);
        
        // 2. Definir el Layout de los JPanels
        panel1.setLayout(new GridLayout(10,2));
        panel2.setLayout(new FlowLayout());
        
        // 3. Colocar los objetos en los JPanels
        panel1.add(new JLabel("CLAVE: "));
        panel1.add(tfClave);
        panel1.add(new JLabel("TITULO: "));
        panel1.add(tfTitulo);
        panel1.add(new JLabel("AUTOR: "));
        panel1.add(tfAutor);
        panel1.add(new JLabel("EDITORIAL: "));
        panel1.add(tfEditorial);
        
        panel1.add(new JLabel("Stock Existencia: "));
        panel1.add(tfExistencia);
        
        panel1.add(new JLabel("PRECIO: "));
        panel1.add(tfPrecio);
        
        panel1.add(bCapturar);
        panel1.add(bConsultar);
        panel1.add(bConsultarClave);
        panel1.add(bConsultarEditorial);
        panel1.add(bActualizarStock);
        panel1.add(bVenta);
        panel1.add(bCancelar);
        panel1.add(bSalir);
        
        panel2.add(panel1);
        panel2.add(new JScrollPane(taDatos));
        
        // 4. Adicionar los JPanels al JFrame
        add(panel2);
        
        // 5. Visualizar el JFrame
        setSize(400,440);
        setVisible(true);
    }
    
    private void activarBotones()
    {
    	bActualizarStock.setEnabled(false);
        bCancelar.setEnabled(false);
        bVenta.setEnabled(false);
        
        
        bCapturar.setEnabled(true);
        bConsultar.setEnabled(true);
        bConsultarEditorial.setEnabled(true);
        bConsultarClave.setEnabled(true);
    }
    
    private void inactivarBotones()
    {
    	bActualizarStock.setEnabled(true);
        bCancelar.setEnabled(true);
        bVenta.setEnabled(true);
        
        bCapturar.setEnabled(false);
        bConsultar.setEnabled(false);
        bConsultarEditorial.setEnabled(false);
        bConsultarClave.setEnabled(false);
    }
    
    private String obtenerDatos()
    {
        String datos="";
        
        String clave  = tfClave.getText();
        String titulo = tfTitulo.getText();
        String autor  = tfAutor.getText();
        String edit   = tfEditorial.getText();
        String stock  = tfExistencia.getText();
        String pre    = tfPrecio.getText();
        int cantidad;
        float precio;
        
        if(clave.isEmpty() || titulo.isEmpty() || autor.equals("") || edit.isEmpty()|| stock.isEmpty() || pre.isEmpty())
        {
            datos = "VACIO";
        }
        else
        {
            try
            {
                cantidad = Integer.parseInt(stock);
                precio   = Float.parseFloat(pre);
                
                datos = clave+"_"+titulo+"_"+autor+"_"+edit+"_"+stock+"_"+pre;
            }
            catch(NumberFormatException nfe)
            {
                datos = "NO_NUMERICO";
            }
        }
        
        return datos;
    }
    
    public void actionPerformed(ActionEvent e)
    {
        String datos, resultado;
        
        if(e.getSource() == bCapturar)
        {
            // 1. Obtener datos de los JTextFields
            datos = obtenerDatos();
            
            if(datos.equals("VACIO"))
                resultado = "Algun dato esta vacio...";
            else
                if(datos.equals("NO_NUMERICO"))
                    resultado = "Stock y Precio deben ser numericos...";
                else
                    // 2. Capturar datos en el archivo
                    resultado = biblioad.capturar(datos);
            
            // 3. Desplegar resultado de la Transaccion
            taDatos.setText(resultado);
        }
        
        if(e.getSource() == bConsultar)
        {
            // 1. Consultar libros
            datos = biblioad.consultarLibros();
            
            // 2. Desplegar datos
            taDatos.setText(datos);
        }
        
        if(e.getSource() == bConsultarEditorial)
        {
            // 1. Obtener del tfEditorial la editorial a buscar
            String edit = tfEditorial.getText();
            
            if(edit.isEmpty())
            {
            	datos = "VACIO";
            }
            else
            {
            	// 2. Consultar libros de la editorial
            	datos = biblioad.consultarEditorial(edit);
            
            	if(datos.equals("NOT_FOUND"))
                	datos = "No se localizo la Editorial: "+edit;
            }
                        
            
            // 3. Desplegar datos
            taDatos.setText(datos);
        }
        
        if(e.getSource() == bConsultarClave)
        {
            // 1. Obtener del tfClave la clave a buscar
            String cve = tfClave.getText();
            
            if(cve.isEmpty())
            {
            	datos = "VACIO";
            }
            else
            {
            	// 2. Consultar libros de la editorial
            	datos = biblioad.consultarClave(cve);
            
	            if(datos.equals("NOT_FOUND"))
	                datos = "No se localizo la Clave: "+cve;
	            else
	            	inactivarBotones();	
            }
            
                        
            // 3. Desplegar datos
            taDatos.setText(datos);
        }
        
        if(e.getSource() == bActualizarStock)
        {
        	//1. Obtener la Clave del Libro y la cantidad a actualizar el stock
        	String clave = tfClave.getText();
        	if(clave.isEmpty())
        	{
        		resultado = "COLOQUE UNA CLAVE DE LIBRO";
        	}
        	else
        	{
        		int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Cantidad a Agregar ="));
        	
        		//2. Hacer actualizacion del stock 
        		resultado = biblioad.actualizarStock(clave,cantidad);	
        	}
        	
        	
        	//3. Desplegar el resultado de la transaccion
        	taDatos.setText(resultado);
        	activarBotones();
        }
        
        if(e.getSource() == bVenta)
        {
        	//1. Obtener la Clave del Libro y la cantidad a vender el stock
        	String clave = tfClave.getText();
        	if(clave.isEmpty())
        	{
        		resultado = "COLOQUE UNA CLAVE DE LIBRO";
        	}
        	else
        	{
        		int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Cantidad a vender ="));
	        	
	        	//2. Hacer actualizacion del stock 
	        	resultado = biblioad.ventaLibro(clave,cantidad);	
        	}
        	
        	
        	//3. Desplegar el resultado de la transaccion
        	taDatos.setText(resultado);
        	 activarBotones();
        }
        
        if(e.getSource() == bCancelar)
        {
            activarBotones();
        }
        
        if(e.getSource() == bSalir)
        {
            System.exit(0);
        }
    }
    
    public static void main(String args[])
    {
        new LibroGUI();
    }
}
